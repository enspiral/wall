<div class="container text">
    <p class="text-orange text-title">Recruitment</p><hr style="margin-top:-5px; margin-bottom:10px;">
    <div style="width:850px; height:auto;"><img src="images/socail/recruitment.jpg" width="850" height="400"></div> 
    <div style="background-color:#F5F5F5; margin-top:16px;"><p>Join us in making volunteerism more impactful for both you and your beneficiaries! Spread the word, join our team, launch a local chapter or just like our Facebook page todayJoin us in making volunteerism more impactful for both you and your beneficiaries! Spread the word, join our team, launch a local chapter or just like our Facebook page today.Join us in making volunteerism more impactful for</p></div>
    <button class="btn btn-info create-recruitment">Join Us NOW!</button>
</div>