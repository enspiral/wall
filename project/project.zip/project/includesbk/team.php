<style>
    .team-page{
        padding-bottom: 50px;
    }
    .profile_show img{
    	margin-right:5px;
    }
    
</style>

<div class="row text team-page">
    <p class="text-orange text-title">Our Team</p><hr style="margin-top:-5px; margin-bottom:10px;">
    <div class="col-md-7 project_team_profile" style="padding-bottom:120px;">
         <?php
        $friendslist=$Wall->Group_Followers($group_id,'', '', 35);

        if($friendslist)
        {
        $list_count = 1;
        foreach($friendslist as $f)
        {
            $fid=$f['uid'];
            $fname=$f['username'];
            $friend_face=$Wall->User_Profilepic($fid,$base_url,$upload_path);
            $top1 = 0;
            $top2 = 170;
         //   echo '<a href="'.$base_url.$fname.'" ><img src="'.$friend_face.'" height=80 width=80 class="tansef" original-title="'.$Wall->UserFullName($fname).'" ></a>';
            if($list_count == 1){
                echo '<div class="profile_show">';
            }
            $list_count = 0;
            echo '<div><div class="tansef"><img src="'.$friend_face.'" height=70 width=70 original-title="'.$Wall->UserFullName($fname).'" ></div>';
            echo '<div class="tansa" style="top:'.$top1.'px;"><a href="'.$base_url.'other_dashboard.php?username='.$fname.'" ><img  src="'.$friend_face.'" height=160 width=160 class="tansef" original-title="'.$Wall->UserFullName($fname).'" ></a></div>';
            echo '<div class="arrow" style="top:'.$top2.'px; width:160px;">'.'<center>Name: '.$fname.'<br>Role: Leader</center>'.'</div></div>';
        }
        echo '</div>';
        }
        ?>
        
        
        

    </div>
    <div class="col-md-5 text-center team-profile" style="display:none;">
        <img src="<?php echo $base_url; ?>uploads/user_41412736208.jpg" />
        <p>Name here</p>
        <p>Role here</p>
        <p class="text-left">Quote goes here. Text is left aligned.</p>
        <p class="text-left">Limit to 20 words</p>
        <p><a href="">View Profile</a></p>
    </div>
</div>


<script>
    $('.tansef').css('cursor','pointer');
    $('.tansa:first').show();
    $('.arrow:first').show();
    $('.tansef').click(function(){   
        $(".tansa").hide();
        $(".arrow").hide();
        var sh = $(this).siblings('.tansa');
        var sharrow = $(this).siblings('.arrow');
        sh.fadeIn().siblings("div").hide;
        sharrow.fadeIn().sibling("div").hide;
    });
</script>