<div class="container text">
    <p class="text-orange text-title">Recruitment</p><hr style="margin-top:-5px; margin-bottom:10px;">
    <h2 class="text-center">The Recruitment Page is coming soon !!!</h2>
</div>