 var loadCSS = function(url, callback){
                var link = document.createElement('link');
                link.type = 'text/css';
                link.rel = 'stylesheet';
                link.href = url;
                link.id = 'theme-style';

                document.getElementsByTagName('head')[0].appendChild(link);

                var img = document.createElement('img');
                img.onerror = function(){
                    if(callback) callback(link);
                }
                img.src = url;
            }

            $(document).ready(function() {
                var initEditor = function() {
                    $(".text-editor").sceditor({
                        plugins: 'bbcode',
                        style: "css/editor/jquery.sceditor.default.min.css"
                    });
                };

                $("#theme").change(function() {
                    var theme = "js/editor/jquery.sceditor.bbcode.min.js" + $(this).val() + ".min.css";

                    $(".text-editor").sceditor("instance").destroy();
                    $("link:first").remove();
                    $("#theme-style").remove();

                    loadCSS(theme, initEditor);
                });

                initEditor();
            });