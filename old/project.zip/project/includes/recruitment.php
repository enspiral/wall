<script src="js/lib-scrool/1.6.1.jquery.min.js"></script>
<script>
  $(".back-top").hide();
  // fade in #back-top
  $(function () {
    $(window).scroll(function () {
      if ($(this).scrollTop() > 100) {
        $('.back-top').fadeIn();
      } else {
        $('.back-top').fadeOut();
      }
    });

    // scroll body to 0px on click
    $('.back-top a').click(function () {
      $('body,html').animate({
        scrollTop: 0
      }, 800);
      return false;
    });
  });

// });
</script>

<?php
    $query = mysqli_query($db, "SELECT * FROM  recruitment");
    foreach ($query as $value) {
            $recruitment_des = $value['recruit_text'];
            $recruit_image = $value['recruit_image'];
            $recruit_id = $value['recru_id'];
    }
    ?>
     <p class="text-right"></p>
<div class="container text">
	 	
               <div class="block-right">    
           <a href="" data-toggle="modal" data-target="#recruit_image"><i class="glyphicon glyphicon-edit custom-file-input" original-title="edit recruit_image" data-toggle="modal" data-target="#modal_recruitment"></i></a>
             
	<div class="modal fade" id="modal_recruitment" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
             <form method="post" enctype='multipart/form-data' action="">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="exampleModalLabel">Edit Recruitment</h4>
            </div>
            <div class="modal-body">
              <form>
                <!-- Image:  <input type="file" name="<?php //echo 'tl_image_'.$content_id; ?>" id="<?php //echo 'tl_image_'.$content_id; ?>" style="display:inline;"> -->
                <input type="file" id="recruit_image" name="recruit_image" value="<?php echo $recruit_image; ?>"/><br/>
                <textarea id="recruitment_des" name="recruitment_des" style="width:100%; height:150px;"><?php echo $recruitment_des; ?></textarea>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</button>
                <button id="submit_recruiment" name="submit_recruiment" class="btn btn-sm btn-primary update-profile">Update</button>
            </div>
        </form>
        </div>
    </div>
</div>
<!-- the end of edit recrument -->

    <p class="text-orange text-title">Recruitment</p><hr style="margin-top:-5px; margin-bottom:10px;">
    <div style="width:850px; height:400; background-color:#F5F5F5;">
        <?php  $tl_pic = $base_url.'images/'.$recruit_image;
        echo '<div class="recrument-image"><img src="'.$tl_pic.' width: 800px;
  height: 400px;"/></div>';
        ?>
    </div> 
    <div style="background-color:#F5F5F5; margin-top:16px;"><p><?php echo $recruitment_des; ?></p></div>
    <button class="btn btn-info create-recruitment">Join Us NOW!</button>
</div>
</div>
