<div class="container text">
    <p class="text-orange text-title">Support Us</p><hr style="margin-top:-5px; margin-bottom:10px;">
    <h2 class="text-center">The Donate page is coming Soon !!!</h2>
</div>